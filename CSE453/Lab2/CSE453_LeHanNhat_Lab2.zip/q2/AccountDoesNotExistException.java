package lab2.q2;

public class AccountDoesNotExistException extends Exception {
	static final long serialVersionUID = 1L; 
}
