package com.example.demoCse453;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCse453ApplicationTests {

	@Test
	void contextLoads() {
	}

}
