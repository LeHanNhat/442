package com.example.demoCse453;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCse453Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoCse453Application.class, args);
	}

}
