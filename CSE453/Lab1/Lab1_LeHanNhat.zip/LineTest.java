package lab1q5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LineTest {

	@Test
	void testLine() {
		Line line = new Line(null, null);
	}

}
